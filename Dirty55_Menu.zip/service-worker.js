// ضع هنا كود Service Worker الخاص بالتطبيق PWA
